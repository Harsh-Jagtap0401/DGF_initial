
import './App.css'
// import Sidebar from './components/FixedNavigation/Sidebar'
// import Header from './components/FixedNavigation/Header'
import FixedComponent from './components/FixedComponent'
import TrainingContainer from './components/TrainingContainer'

function App() {
  const obj={
    BackgroundColor: "white",
    color: "black"
  }
  return (
    <div style={obj}>
     <FixedComponent></FixedComponent>
     <TrainingContainer></TrainingContainer>
      
     </div>
  )
}

export default App
