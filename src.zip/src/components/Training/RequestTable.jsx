import { useState } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Avatar, Typography, IconButton, TablePagination, Tabs, Tab, TextField, MenuItem } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import ArrowCircleRightOutlinedIcon from '@mui/icons-material/ArrowCircleRightOutlined';
import "../Training/RequestTable.css";

const data = [
  { id: "123", project: "iAlign", learners: 5, objective: "Upskilling", techStack: "Accessibility", requestedOn: "Jan 20, 2025", status: "In Progress" },
  { id: "231", project: "Staffing Nation", learners: 5, objective: "Upskilling", techStack: "React", requestedOn: "Jan 20, 2025", status: "In Progress", progress: "2/7 Completed" },
  { id: "321", project: "Other Project Name", learners: 3, objective: "Upskilling", techStack: "Soft Skills", requestedOn: "Jan 15, 2025", status: "Incomplete" },
  { id: "322", project: "Another Project", learners: 4, objective: "Upskilling", techStack: "Python", requestedOn: "Jan 8, 2025", status: "Completed" },
  { id: "323", project: "Yet Another Project", learners: 3, objective: "Upskilling", techStack: "Node.js", requestedOn: "Jan 5, 2025", status: "Rejected" },
  { id: "324", project: "Hold Project", learners: 2, objective: "Upskilling", techStack: "Java", requestedOn: "Jan 2, 2025", status: "Hold" }
];


const statuses = ["In Progress", "Completed", "Incomplete", "Rejected", "Hold"];
const daysOptions = ["Last 7 days", "Last 30 days", "Last 90 days", "All"];

const RequestTable = () => {
  const [page, setPage] = useState(0);
  const [selectedStatus, setSelectedStatus] = useState("In Progress");
  const [selectedDays, setSelectedDays] = useState("All");
  const rowsPerPage = 5;

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleStatusChange = (event, newValue) => {
    setSelectedStatus(statuses[newValue]);
    setPage(0);
  };

  const handleDaysChange = (event) => {
    setSelectedDays(event.target.value);
    setPage(0);
  };

  const filteredData = data.filter(row => row.status === selectedStatus);

  return (
    <TableContainer component={Paper} className="table-container">
      <div className="filters">
        <Tabs value={statuses.indexOf(selectedStatus)} onChange={handleStatusChange} variant="scrollable" scrollButtons="auto">
          {statuses.map(status => (
            <Tab key={status} label={`${status} (${data.filter(row => row.status === status).length})`} />
          ))}
        </Tabs>
        <TextField
          select
          value={selectedDays}
          onChange={handleDaysChange}
          variant="outlined"
          size="small"
          style={{ marginLeft: '20px' }}
        >
          {daysOptions.map(option => (
            <MenuItem key={option} value={option}>
              {option}
            </MenuItem>
          ))}
        </TextField>
      </div>
      <Table>
        <TableHead>
          <TableRow className="table-head">
            <TableCell>Req No</TableCell>
            <TableCell>Project</TableCell>
            <TableCell>Learners</TableCell>
            <TableCell>Objective</TableCell>
            <TableCell>Tech Stack</TableCell>
            <TableCell>Requested On</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {filteredData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
            <TableRow key={index}>
              <TableCell>{row.id}</TableCell>
              <TableCell>{row.project}</TableCell>
              <TableCell><Avatar>{row.learners}</Avatar></TableCell>
              <TableCell>{row.objective}</TableCell>
              <TableCell>{row.techStack}</TableCell>
              <TableCell>{row.requestedOn}</TableCell>
              <TableCell>
                <Typography color={row.status.includes("Progress") ? "primary" : "textSecondary"}>
                  {row.status} {row.progress ? `(${row.progress})` : ""}
                </Typography>
              </TableCell>
              <TableCell>
                <IconButton><ArrowCircleRightOutlinedIcon /></IconButton>
                <IconButton><EditIcon /></IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[5]}
        component="div"
        count={filteredData.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
      />
    </TableContainer>
  );
};

export default RequestTable;