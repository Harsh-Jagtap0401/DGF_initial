import Dashboard from "./Training/Dashboard"
import RequestTable from "./Training/RequestTable"
import TrainingHeaderBtn from "./Training/TrainingHeaderBtn"

const TrainingContainer = () => {
  const styles = {
    mainContent:{
      flex:'auto',
      overflowY:'auto',
      height: '100vh', // Ensure the container takes the full height of the viewport
      boxSizing: 'border-box' ,
      padding: '10px 10px 0 0',
      // width: 'calc(100% - 280px)',
      marginLeft: '240px',
      marginright: '0'
    }
  }
  return (
    <div style={styles.mainContent}>
<TrainingHeaderBtn></TrainingHeaderBtn>
      <RequestTable></RequestTable>
      <Dashboard></Dashboard>
    </div>
  )
}

export default TrainingContainer
