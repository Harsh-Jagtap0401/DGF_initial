
import FixedComponent from "./FixedComponent"
const NewRequestContainer = () => {
  return (
    <div>

<FixedComponent>
    
</FixedComponent>
    </div>
  )
}

export default NewRequestContainer